# FAQs (frequently asked questions)

This directory contains some documents discussing frequently asked
questions

 - 1 - [Why is it not as fast as I expect?](FAQ0001-slow.md)
 - 2 - [Why are many results missing that I expect?](FAQ0002-drops.md)
 - 3 - [How can I add my IPs to an official exlude list, to get people to stop scanning me?](FAQ0003-excludelist.md)
