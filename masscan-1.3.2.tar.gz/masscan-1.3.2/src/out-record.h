#ifndef OUT_RECORD_H
#define OUT_RECORD_H

enum OutputRecordType {
    Out_Open = 1,
    Out_Closed = 2,
    Out_Banner1 = 5,
    Out_Open2 = 6,
    Out_Closed2 = 7,
    Out_Arp2 = 8,
    Out_Banner9 = 9,
    Out_Open6 = 10,
    Out_Closed6 = 11,
    Out_Arp6 = 12,
    Out_Banner6 = 13,

};
#endif
